#ifndef __Picture_H__
#define __Picture_H__

#include "lcd.h"
extern const unsigned char gImage_LCD280[153600];

#endif



















