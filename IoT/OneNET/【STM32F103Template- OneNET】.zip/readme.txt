1.触摸屏测试案例移植工程模板
2.修改工程框架 建立main.h
3.添加传感器驱动
4.   STM32F103ZET6 ESP8266 WiFi模组 物联网通信测试实验 
  --->中移OneNET云平台测试 连接云平台，发送数据  <---
   1.重要的网络协议文件Network  
    #include "esp8266.h"   //无线模块 底层驱动，与串口2进行通信
    #include "onenet.h"    //中移OneNET云平台网络协议 与onenet平台的数据交互接口层
    #include "mqttkit.h"  // 基本的MQTT协议处理
   2.接入中移OneNET云平台的步骤
      (1)注册onenet平台账号 https://open.iot.10086.cn/
      (2)登录账号 点击控制台 选择 “多协议连接”
      (3)实验通过MQTT协议进行的 添加并创建产品，填写产品信息 (产品名称 产品行业 产品类别 联网方式移动蜂窝网络 设备接入协议 MQTT旧版 操作系统：无 )
      (4)选择产品，创建设备，（填写 设备名称，鉴权信息，非常重要） 设备创建完成
      (5)硬件准备

			esp8266对应接线
			TX -> PA3
			RX -> PA2
			使用的是STM32F103ZET6的串口二
			注意：esp8266进行连接时注意杜邦线是否松了，可能会连接不成功多试几次就好了

      (6)代码移植

      	在onenet.c文件中 修改
      	#define DEV_ID			"885358528"     //设备ID
      	#define PRODUCT_ID		"487526"  		//产品ID
		#define AUTH_INFO		"boardstm32"    //鉴权信息

      	在esp8266.c文件中 修改
		#define ESP8266_WIFI_INFO		"AT+CWJAP=\"dele\",\"delehub2022\"\r\n"  			// 热点名称，热点密码
		#define ESP8266_ONENET_INFO            "AT+CIPSTART=\"TCP\",\"183.230.40.39\",6002\r\n"    // OneNET 提供的MQTT 端口 ip


			
		主函数调用串口2初始化
		
		unsigned short timeCount = 0;	//发送间隔变量
		unsigned char *dataPtr = NULL;


		USART1_Config(115200);//串口初始化波特率为115200 
    		USART2_Config(115200);//ESP8266 通讯串口2  波特率为115200 



		ESP8266_Init();//ESP8266初始化
		while(OneNet_DevLink())//接入onenet
		delay_ms(500);

		Beep_Set(BEEP_ON);				//鸣叫接入成功
		delay_ms(250);
		Beep_Set(BEEP_OFF);
    		while(1)
  		  {
     			   if(++timeCount >= 40)		//发送间隔1s，也就是5s上传一次数据，1000/25=40
			{
				AHT10_Read_Humi_Temp(&aht_hum,&aht_temp);
				UsartPrintf(USART_DEBUG, "OneNet_SendData\r\n");
				OneNet_SendData();
			
				timeCount = 0;
				ESP8266_Clear();
			}
		
		  dataPtr = ESP8266_GetIPD(3);//完成需要15个毫秒，三次循环，一次5个毫秒
		  if(dataPtr != NULL)
	   	  OneNet_RevPro(dataPtr);
		  delay_ms(10);        
   		 }




