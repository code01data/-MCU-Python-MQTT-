#ifndef AL_DEBUG_H
#define AL_DEBUG_H


#define g_version	"General_App_V1.0.0"

#define al_debug_log(format, ...) printf("<ST>F:"__FILE__"\tL:%d>> "format"<END>\r\n",__LINE__,##__VA_ARGS__)

#ifndef AL_DEBUG_FILE_DEBUG
#define AL_DEBUG_FILE_DEBUG			1
#endif

#define USART1_DEBUG		USART1		//调试打印所使用的串口组
#define USART2_DEBUG		USART2
#define USART3_DEBUG		USART3

void AL_DEBUG_LOG(USART_TypeDef *USARTx, char *fmt,...);
void al_main_task_log_start(void);


#define PRINT_DEBUG_ENABLE		1		/* 打印调试信息 */
#define PRINT_ERR_ENABLE	    1	    /* 打印错误信息 */
#define PRINT_INFO_ENABLE		1		/* 打印个人信息 */


#if PRINT_DEBUG_ENABLE
#define PRINT_DEBUG(fmt, args...) 	 do{(printf("\n[DEBUG] >> "), printf(fmt, ##args));}while(0)     
#else
#define PRINT_DEBUG(fmt, args...)	     
#endif

#if PRINT_ERR_ENABLE
#define PRINT_ERR(fmt, args...) 	 do{(printf("\n[ERR] >> "), printf(fmt, ##args));}while(0)     
#else
#define PRINT_ERR(fmt, args...)	       
#endif

#if PRINT_INFO_ENABLE
#define PRINT_INFO(fmt, args...) 	 do{(printf("\n[INFO] >> "), printf(fmt, ##args));}while(0)     
#else
#define PRINT_INFO(fmt, args...)	       
#endif

/**@} */
	
//针对不同的编译器调用不同的stdint.h文件
#if defined(__ICCARM__) || defined(__CC_ARM) || defined(__GNUC__)
    #include <stdint.h>
#endif

/* 断言 Assert */
#define AssertCalled(char,int) 	printf("\nError:%s,%d\r\n",char,int)
#define ASSERT(x)   if((x)==0)  AssertCalled(__FILE__,__LINE__)
  
typedef enum 
{
	ASSERT_ERR = 0,								/* 错误 */
	ASSERT_SUCCESS = !ASSERT_ERR	/* 正确 */
} Assert_ErrorStatus;

typedef enum 
{
	FALSE = 0,		/* 假 */
	TRUE = !FALSE	/* 真 */
}ResultStatus;


#endif

