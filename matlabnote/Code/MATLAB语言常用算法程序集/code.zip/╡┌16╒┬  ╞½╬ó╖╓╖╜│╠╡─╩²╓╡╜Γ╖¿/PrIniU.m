function ux = PrIniU(x)
format long;
ux = sin(x);
