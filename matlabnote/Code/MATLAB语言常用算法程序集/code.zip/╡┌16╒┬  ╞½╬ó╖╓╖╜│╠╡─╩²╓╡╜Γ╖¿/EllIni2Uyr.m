function uxy = EllIni2Uyr(x,y)
format long;
if x < 1
    uxy = x;
else  
    uxy = 2 - x;
end