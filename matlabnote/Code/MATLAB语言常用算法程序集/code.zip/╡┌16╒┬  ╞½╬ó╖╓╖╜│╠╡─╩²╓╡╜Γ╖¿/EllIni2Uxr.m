function uxy = EllIni2Uxr(x,y)
format long;
uxy = y*(2-y);