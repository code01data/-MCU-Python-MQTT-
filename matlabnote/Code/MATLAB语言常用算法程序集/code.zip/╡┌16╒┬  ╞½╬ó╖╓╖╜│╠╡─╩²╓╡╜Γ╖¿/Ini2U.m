function uxy = Ini2U(x,y)
format long;
uxy = exp(-10*x*x-10*y*y);